################################################################################
# IPW with low propensity score, empirical application
# Xinwei Ma and Jingshen Wang
################################################################################

library(foreign); library(MASS); library(Hmisc)
library(plotrix)

set.seed(42)

axis.scale <- 1.3
axis.gap <- 3

######## experimental benchmark ########
data <- read.csv("LaLonde_all.csv", header=T)
benchmark <- mean(data$re78[data$treat==1]) - mean(data$re78[data$treat==0])

################################################################################
# data
################################################################################
data <- read.csv("LaLonde-PSID.csv", header=T)
n <- nrow(data)
temp <- glm(treat ~ age + I(age^2) + educ + I(educ^2) + married + black + hisp + re74 + I(re74^2) + re75 + I(re75^2) + I(u74*black), data=data, family=binomial)
data$pscore <- temp$fitted.values

################################################################################
# bn sequence (trimming)
################################################################################
temp <- lm(re78 ~ pscore, data=data[data$treat==0 & data$pscore >= 0.5, ])
c1 <- temp$coefficients[1] + temp$coefficients[2]
temp <- lm(I(re78^2) ~ pscore, data=data[data$treat==0 & data$pscore >= 0.5, ])
c2 <- temp$coefficients[1] + temp$coefficients[2]
bfactor <- c2 / c1^2

bandChoose <- function(a, b, X) {
  if (a == -1) {
    return (0)
  } else {
    optimize(function(x) abs(x^a * mean(X<=x) - b), lower=0, upper=1, maximum=FALSE)$minimum
  }
}

bnT <- c(-1, 1, 1.3, 2, 2.5, 3, 3.5) # controls the amount of trimming
hnT <- c(0.2) # loc pol bandwidth

################################################################################
# point estimate
################################################################################
repe <- 1000

A <- BR <- HR <- S <- CL <- CR <- matrix(NA, nrow=length(bnT), ncol=length(hnT))
Abs <- CLbs <- CRbs <- matrix(NA, nrow=length(bnT), ncol=length(hnT))
for (i in 1:nrow(A)) for (j in 1:ncol(A)) {
  cat(i); cat("\n")
  
  br <- 1-bandChoose(bnT[i], bfactor/(2*n), 1-data$pscore)
  hr <- 1 - bandChoose(5, hnT[j]/n, 1-data$pscore)
  BR[i, j] <- br
  HR[i, j] <- hr

  tempR <- lm(re78 ~ pscore, data=data[data$treat==0 & data$pscore >= hr, ])$coefficients
  
  A[i, j] <- mean(data$treat * data$re78 - 
                    (1-data$treat) * data$re78 * data$pscore / (1-data$pscore) * (data$pscore <= br) - 
                    (tempR[1] + tempR[2] * data$pscore) * data$pscore * (data$pscore >= br)) * n / sum(data$treat)
  
  S[i, j] <- sd(data$treat * data$re78 - 
                  (1-data$treat) * data$re78 * data$pscore / (1-data$pscore) * (data$pscore <= br) - 
                  (tempR[1] + tempR[2] * data$pscore) * data$pscore * (data$pscore >= br)) * n / sum(data$treat) / sqrt(n)
  ######## subsampling ########
  nSS <- floor(n/log(n))
  tempA <- rep(NA, repe)
  tempS <- rep(NA, repe)
  for (ss in 1:repe) {
    # pscore
    indexSS <- sample(1:n, nSS, replace=FALSE)
    dataSS <- data[indexSS, ]
    temp <- glm(treat ~ age + I(age^2) + educ + I(educ^2) + married + black + hisp + re74 + I(re74^2) + re75 + I(re75^2) + I(u74*black), 
                data=dataSS, family=binomial) 
    dataSS$pscore <- temp$fitted.values
    ######## point estimate ########
    br <- 1-bandChoose(bnT[i], bfactor/(2*nSS), 1-dataSS$pscore)
    hr <- 1 - bandChoose(5, hnT[j]/nSS, 1-dataSS$pscore)
    
    if (sum(dataSS$treat==0 & dataSS$pscore >= hr) <= 2) {
      tempR <- c(0, 0)
    } else { 
      tempR <- lm(re78 ~ pscore, data=dataSS[dataSS$treat==0 & dataSS$pscore >= hr, ])$coefficients
    }
    
    tempA[ss] <- mean(dataSS$treat * dataSS$re78 - 
                        (1-dataSS$treat) * dataSS$re78 * dataSS$pscore / (1-dataSS$pscore) * (dataSS$pscore <= br) - 
                        (tempR[1] + tempR[2] * dataSS$pscore) * dataSS$pscore * (dataSS$pscore >= br)) * nSS / sum(dataSS$treat)
    tempS[ss] <- sd(dataSS$treat * dataSS$re78 - 
                      (1-dataSS$treat) * dataSS$re78 * dataSS$pscore / (1-dataSS$pscore) * (dataSS$pscore <= br) - 
                      (tempR[1] + tempR[2] * dataSS$pscore) * dataSS$pscore * (dataSS$pscore >= br)) * nSS / sum(dataSS$treat) / sqrt(nSS)
  }
  CL[i, j] <- A[i, j] - quantile((tempA - A[i, j]) / tempS, 0.975, na.rm=TRUE) * S[i, j]
  CR[i, j] <- A[i, j] - quantile((tempA - A[i, j]) / tempS, 0.025, na.rm=TRUE) * S[i, j]
  
  ######## conventional inference ########
  if (j == 1) {
    br <- BR[i, j]
    Abs[i,] <- mean(data$treat * data$re78 - 
                       (1-data$treat) * data$re78 * data$pscore / (1-data$pscore) * (data$pscore <= br)) * n / sum(data$treat)
    Absss <- rep(NA, repe)
    for (ss in 1:repe) {
      dataBSss <- data[sample(1:nrow(data), nrow(data), replace=TRUE), ]
      temp <- glm(treat ~ age + I(age^2) + educ + I(educ^2) + married + black + hisp + re74 + I(re74^2) + re75 + I(re75^2) + I(u74*black), 
                  data=dataBSss, family=binomial) 
      dataBSss$pscore <- temp$fitted.values
      Absss[ss] <- mean(dataBSss$treat * dataBSss$re78 - 
                          (1-dataBSss$treat) * dataBSss$re78 * dataBSss$pscore / (1-dataBSss$pscore) * (dataBSss$pscore <= br)) * n / sum(dataBSss$treat)
    }
    CLbs[i, ] <- Abs[i, 1] - 1.96 * sd(Absss) 
    CRbs[i, ] <- Abs[i, 1] + 1.96 * sd(Absss)  
  }
  
}

################################################################################
# plot
################################################################################

fname <- paste("ATT", ".pdf", sep="")
pdf(fname, height=7, width=12)
par(mar=c(4,5,1,1)+0.1)
from=10000; to=40000
plot(-1, -50000, type="n", xlab="", ylab="", ylim=c(-3000, 6000), xlim=c(1.0, 7.8), axes=FALSE)
abline(h=0, col="grey", lty=2)
abline(h=benchmark)
text(0.95, benchmark+150, "$1794", cex=axis.scale)

axis(2, seq(-10000, 10000, 2000), seq(-10000, 10000, 2000), cex.axis=axis.scale)
axis(2, seq(-10000, 10000, 1000), FALSE, cex.axis=axis.scale)
for (j in 1:7) {
  
  points(j+0.4, A[j, 1], pch=17, cex=1)
  lines(c(j+0.4-0.06, j+0.4+0.06), rep(CL[j, 1], 2), lwd=1)
  
  #points(j+0.3, CR[j, 4], pch=16, cex=1)
  
  if (CR[j, 1] > from) {
    lines(c(j+0.4-0.06, j+0.4+0.06), rep((CR[j, 1]-10000)/5+10000, 2), lwd=1)
    lines(rep(j+0.4, 2), c(CL[j, 1], (CR[j, 1]-10000)/5+10000), lwd=1, lty=1)
  } else {
    lines(c(j+0.4-0.06, j+0.4+0.06), rep(CR[j, 1], 2), lwd=1)
    lines(rep(j+0.4, 2), c(CL[j, 1], CR[j, 1]), lwd=1, lty=1)
  }
  
  
  if (j >= 1) {
    points(j+0.6, Abs[j, 1], pch=16, cex=1)
    
    lines(c(j+0.6-0.06, j+0.6+0.06), rep(CLbs[j, 1], 2), lwd=1)
    
    lines(c(j+0.6-0.06, j+0.6+0.06), rep(CRbs[j, 1], 2), lwd=1)
    lines(c(j+0.6, j+0.6), c(CLbs[j, 1], CRbs[j, 1]), lty=2)
    
    
  }
  if (j >= 2) {
    axis(1, j+0.5, paste("[", format(signif(BR[j, 1], 2), nsmall=2), " ,1]", sep=""), cex.axis=axis.scale)
    text(x=j+0.5,  par("usr")[3]-600, 
         labels = paste(sum(data$pscore>=BR[j, 1] & data$treat==0), sep=""), pos = 1, xpd = TRUE, cex=axis.scale)
  }
}


axis(1, 1+0.5, "no", cex.axis=axis.scale)
text(x=1+0.5,  par("usr")[3]-600, 
     labels = "trimming", pos = 1, xpd = TRUE, cex=axis.scale)
title(ylab=paste("Estimated ATT ($)",sep=""), line=axis.gap, cex.lab=axis.scale)

lines(c(6, 6.5), c(-1400-1200, -1400-1200))
lines(c(6, 6), c(-1300-1200, -1500-1200))
lines(c(6.5, 6.5), c(-1300-1200, -1500-1200))
text(6.55, -1400-1200, "Robust 95% CI", pos=4, cex=axis.scale)
points(6.25, -1400-1200, pch=17)

lines(c(6, 6.5), c(-1800-1200, -1800-1200), lty=2)
lines(c(6, 6), c(-1700-1200, -1900-1200))
lines(c(6.5, 6.5), c(-1700-1200, -1900-1200))
text(6.55, -1800-1200, "Conventional 95% CI", pos=4, cex=axis.scale)
points(6.25, -1800-1200, pch=16)


lines(c(5.6-0.2+0.4, 5.6-0.2+0.4), c(-2200, -4000), col="grey"); lines(c(5.6-0.2+0.4, 10), c(-2200, -2200), col="grey")

box()
dev.off()

